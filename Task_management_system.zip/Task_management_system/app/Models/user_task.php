<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class user_task extends Model
{
    use HasFactory;
    protected $table = 'user_task';
    public $timestamps = false;
}
