<!DOCTYPE html>    
<html>    
    <head>    
        <title>Add user - Task management system</title>
        <script>
            <?php if(session()->has('msg')): ?>
                alert("<?php echo e(session()->get('msg')); ?>");
            <?php endif; ?>
        </script>
    </head>    
    <body>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <h1>Add User</h1>
            <form action="<?php echo e(url('/')); ?>/insert_user" method="post">
                <?php echo csrf_field(); ?>
                <table align="center">
                    <tr>
                        <th>Full name : </th>
                        <td><input type="text" name="name" placeholder="Enter full name" required></td>
                    </tr>
                    <tr>
                        <th>Email : </th>
                        <td><input type="email" name="email" placeholder="Enter Email" required></td>
                    </tr>
                    <tr>
                        <th>Password : </th>
                        <td><input type="password" name="pass" placeholder="Enter password" required></td>
                    </tr>
                    <tr>
                        <th></th>
                        <td>
                            <input type="checkbox" id="suser" name="check">
                            <label for="suser">Is superuser</label>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><br><input type="submit"value="Add user"></td>
                    </tr>
                </table>
            </form>
        </div>
    </body>
</html><?php /**PATH D:\MCA\Sem-3\PHP\Task_management_system\resources\views/add_user.blade.php ENDPATH**/ ?>