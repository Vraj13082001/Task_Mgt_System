<html>
<head>
    <title>Login - Task management system</title>
    <link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">
    <script>
        <?php if(session()->has('msg')): ?>
            alert("<?php echo e(session()->get('msg')); ?>");
        <?php endif; ?>
    </script>
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <form action="<?php echo e(url('/')); ?>/postlogin" method="post">
            <?php echo csrf_field(); ?>
            <table align="center">
                <tr>
                    <th>Email : </th>
                    <td><input type="email" placeholder="Enter email" name="email" required></td>
                </tr>

                <tr>
                    <th>Password : </th>
                    <td><input type="password" placeholder="Enter password" name="password" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><br><input type="submit" value="Login"/></td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html><?php /**PATH D:\MCA\Sem-3\PHP\Task_management_system\resources\views/login.blade.php ENDPATH**/ ?>