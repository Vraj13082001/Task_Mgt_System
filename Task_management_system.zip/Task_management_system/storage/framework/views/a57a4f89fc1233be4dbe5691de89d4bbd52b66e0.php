<html>
<head>
    <title>Login - Task management system</title>
    <script>
        <?php if(session()->has('msg')): ?>
            alert("<?php echo e(session()->get('msg')); ?>");
        <?php endif; ?>
    </script>
</head>
<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($is_admin==1): ?>
        <div class="container">
            <h1>User list</h1>
            <table border=1 cellspacing=0 align="center">
                <tr>
                    <th style="width:50">ID</th>
                    <th style="width:150">Name</th>
                    <th style="width:200">Email</th>
                    <th>Superuser</th>
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <?php if( $user['is_superuser'] == 1): ?>
                        <td>Yes</td>
                    <?php else: ?>
                        <td>No</td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php else: ?>
        <div class="container2">
            <h1>Tasks</h1>
            <table border=1 cellspacing=0 align="center">
                <tr>
                    <th style="width:50">No.</th>
                    <th style="width:200">Title</th>
                    <th style="width:400">Description</th>
                    <th style="width:150">Start date</th>
                    <th style="width:150">End date</th>
                    <th style="width:100">Priority</th>
                </tr>
                <?php $__currentLoopData = $assigned_task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($task_detail[$key]->title); ?></td>
                    <td><?php echo e($task_detail[$key]->description); ?></td>
                    <td><?php echo e($row['start_date']); ?></td>
                    <td><?php echo e($row['end_date']); ?></td>
                    <td>
                        <?php if($task_detail[$key]->priority == 1): ?>
                            High
                        <?php elseif($task_detail[$key]->priority == 2): ?>
                            Medium
                        <?php else: ?>
                            Low
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\91846\OneDrive\Desktop\PHP\Task_management_system\resources\views/home.blade.php ENDPATH**/ ?>