<link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">
<div class="nav">
    <nav>
        <a href="<?php echo e(url('/')); ?>/home">Home</a> |
        <?php if($is_admin==1): ?>
        <a href="<?php echo e(url('/')); ?>/add_user">Add user</a> |
        <a href="<?php echo e(url('/')); ?>/add_task">Add task</a> |
        <a href="<?php echo e(url('/')); ?>/assign_task">Assign task</a> |
        <?php endif; ?>
        <a href="<?php echo e(url('/')); ?>/changepass">Change password</a>
        <button id="logout_btn" onclick="logout()">Logout</button>
    </nav>
</div>

<script>
        function logout(){
            if(confirm('Are you sure want to logout ?')){
                window.location.href="<?php echo e(url('/')); ?>/logout";
            }
        }
</script><?php /**PATH C:\Users\91846\OneDrive\Desktop\PHP\Task_management_system\resources\views/header.blade.php ENDPATH**/ ?>