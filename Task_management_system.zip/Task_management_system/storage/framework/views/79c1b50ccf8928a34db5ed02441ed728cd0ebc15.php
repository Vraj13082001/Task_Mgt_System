<!DOCTYPE html>
<html>
<head>
    <title>Assign task - Task management system</title>
    <script>
        <?php if(session()->has('msg')): ?>
            alert("<?php echo e(session()->get('msg')); ?>");
        <?php endif; ?>

        function checkboxes()
        {
            count_selected_task = 0;
            count_selected_user = 0;
            var inputElems = document.getElementsByTagName("input");

            for(var i=0; i<inputElems.length; i++){
                if(inputElems[i].type == "checkbox" && inputElems[i].name == "tasks[]" && inputElems[i].checked == true){
                    count_selected_task++;
                }
                else if(inputElems[i].type == "checkbox" && inputElems[i].name == "users[]" && inputElems[i].checked == true){
                    count_selected_user++;
                }
            }
            
            if(count_selected_task==0){
                alert("Select atleast one task !!!");
                return false;
            }
            else if(count_selected_user==0){
                alert("Select atleast one user !!!");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container3">
        <h1 style="text-align:center">Assign Task</h1>
        
        <form action="<?php echo e(url('/')); ?>/post_assign_task" method="post" onsubmit="return checkboxes()">
        <?php echo csrf_field(); ?>
            <div style="display:flex">

                <table border=1 cellspacing=0 style="flex:50%; margin-right:40px">
                    <caption>Select task</caption>
                    <thead>
                        <tr>
                            <th></th>
                            <th>Title </th>
                            <th>Description </th>
                            <th>Priority </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $taskdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type="checkbox" value="<?php echo e($task->id); ?>" name="tasks[]"></td>
                            <td> <?php echo e($task->title); ?> </td>
                            <td> <?php echo e($task->description); ?> </td>
                            <td>
                                <?php if($task->priority == 1): ?>
                                    High
                                <?php elseif($task->priority == 2): ?>
                                    Medium
                                <?php else: ?>
                                    Low
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <table border=1 cellspacing=0 style="flex:30%;">
                    <caption>Select user</caption>
                    <thead>
                        <tr>
                            <th></th>
                            <th> Name </th>
                            <th> Email </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type="checkbox" value="<?php echo e($user->id); ?>" name="users[]"></td>
                            <td> <?php echo e($user->name); ?> </td>
                            <td> <?php echo e($user->email); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                
            </div>

            <div style="margin-top:20px">
                <table align="center">
                    <caption>Select duration</caption>
                    <tr>
                        <th>Starting date : </th>
                        <td><input type="date" name="start_date" required></td>
                    </tr>
                    <tr>
                        <th>Ending date : </th>
                        <td><input type="date" name="end_date" required></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td ><br><input type="submit" value="Assign task"></td>
                    </tr>
                </table>
            </div>
        </form>
    </div>
</body>

</html><?php /**PATH D:\MCA\Sem-3\PHP\Task_management_system\resources\views/assign_task.blade.php ENDPATH**/ ?>